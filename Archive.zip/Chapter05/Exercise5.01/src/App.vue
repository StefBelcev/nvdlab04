<script setup>
import Greeting from './components/Greeting.vue'
</script>
<template>
  <div id="app">
    <Greeting />
  </div>
</template>
