<template>
  <div>{{ greeting }} {{ who }}</div>
</template>
<script setup>
  const greeting = "Hello";
  const who = "John";
</script>

