<template>
  <Exercise />
</template>

<script setup>
import Exercise from "./components/Exercise5-06.vue";
</script>
