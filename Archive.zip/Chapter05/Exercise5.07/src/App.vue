<template>
  <Movies />
</template>

<script setup>
import Movies from "./components/Movies.vue";
</script>
