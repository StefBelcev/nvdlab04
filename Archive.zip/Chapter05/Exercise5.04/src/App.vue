<template>
  <UserInput />
</template>

<script setup>
import UserInput from "./components/UserInput.vue";
</script>
