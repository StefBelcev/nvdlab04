<script setup>
import Greeting from './components/Greeting.vue'
</script>
<template>
  <div id="app">
    <Greeting who="JavaScript" />
  </div>
</template>
