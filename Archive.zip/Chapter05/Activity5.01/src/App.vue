<template>
  <BlogView />
</template>

<script setup>
import BlogView from "./components/BlogView.vue";
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin: 60px auto 0;
  max-width: 800px;
}
input {
  padding: 6px;
}
</style>
