<template>
  <BlogGallery />
</template>

<script setup>
import BlogGallery from "./components/BlogGallery.vue";
</script>
