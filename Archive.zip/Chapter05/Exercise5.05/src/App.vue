<template>
  <PizzaItem />
</template>

<script setup>
import PizzaItem from "./components/PizzaItem.vue";
</script>
